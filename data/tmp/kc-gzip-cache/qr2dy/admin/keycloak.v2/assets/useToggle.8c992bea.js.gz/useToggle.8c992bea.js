import{r as t}from"./index.0cb2e516.js";function l(s=!1){const[a,e]=t.exports.useState(s),o=t.exports.useCallback(()=>e(r=>!r),[]);return[a,o,e]}export{l as u};
