import{r as t,j as n,ad as s}from"./index.0cb2e516.js";const p=t.exports.forwardRef(({onChange:a,...r},e)=>n(s,{...r,ref:e,onChange:(d,o)=>a?.(o)}));p.displayName="TextInput";export{p as K};
