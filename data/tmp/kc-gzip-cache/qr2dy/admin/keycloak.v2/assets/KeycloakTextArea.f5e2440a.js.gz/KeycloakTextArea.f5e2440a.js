import{r as t,j as n,aE as s}from"./index.0cb2e516.js";const x=t.exports.forwardRef(({onChange:a,...r},e)=>n(s,{...r,ref:e,onChange:(d,o)=>a?.(o)}));x.displayName="TextArea";export{x as K};
